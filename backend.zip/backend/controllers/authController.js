const supabase = require('../services/supabaseService');
const bcrypt = require('bcrypt');  // For password hashing

const register = async (req, res) => {
    const { email, password, name, phone, gender, country } = req.body;

    if (!email || !password || !name || !phone) {
        return res.status(400).json({ error: 'Email, password, name, and phone are required' });
    }

    try {
        // **Hash the password before storing it**
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // **Insert user into "users" table**
        const { data, error } = await supabase
            .from('users')
            .insert([{
                email,
                name,
                phone,
                password: hashedPassword,  // Store the hashed password
                gender,
                country
            }])
            .select();  // Select to return inserted data

        if (error) {
            return res.status(400).json({ error: error.message });
        }

        res.status(201).json({ message: 'User registered successfully', user: data[0] });
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
    }
};

const login = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
    }

    try {
        // **Find user by email**
        const { data: users, error } = await supabase
            .from('users')
            .select('*')
            .eq('email', email)
            .limit(1);

        if (error || users.length === 0) {
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        const user = users[0];

        // **Check password**
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        res.status(200).json({ message: 'User logged in successfully', user });
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
    }
};

// const loanApp = async (req, res) => {
//     const { user, loan_type, amount, status = "pending",source_of_income } = req.body;

//     if (!user) {
//         return res.status(400).json({ error: 'User are required' });
//     }

//     try {
//         // **Find user by email**
//         const { data: loan, error } = await supabase
//             .from('loan_applications')
//             .insert([{
//                 user,
//                 loan_type,
//                 amount,
//                 status,
//                 source_of_income
//             }])
//             .select("*,user:users(id,name,gender,country)");  // Select to return inserted data

//         if (error) {
//             return res.status(400).json({ error: 'Something went wrong.' });
//         }



//         res.status(200).json({ message: 'Loan Applied successfully', loan });
//     } catch (err) {
//         res.status(500).json({ error: 'Internal server error' });
//     }
// };



const loanApp = async (req, res) => {
    const { user, loan_type, amount, duration_months, source_of_income } = req.body;

    if (!user || !loan_type || !amount || !duration_months || !source_of_income) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        // **Check if the user already has an approved loan**
        const { data: existingLoans, error: existingLoansError } = await supabase
            .from('loan_applications')
            .select('*')
            .eq('user', user)
            .eq('loan_type', loan_type)
            .eq('status', 'approved');

        if (existingLoansError) {
            return res.status(400).json({ error: 'Something went wrong while checking existing loans.' });
        }

        if (existingLoans && existingLoans.length > 0) {
            return res.status(400).json({ error: 'You already have an approved same loan. You cannot apply for another same loan until the current one is completed or rejected.' });
        }

        // **Calculate interest and monthly installments**
        const interestRate = duration_months <= 12 ? 0.05 : 0.10; // 5% for 1 year or less, 10% for more than 1 year
        const totalInterest = amount * interestRate * (duration_months / 12);
        const totalAmount = amount + totalInterest;
        const monthlyInstallment = totalAmount / duration_months;

        // **Insert the loan application**
        const { data: loan, error: loanError } = await supabase
            .from('loan_applications')
            .insert([{
                user,
                loan_type,
                amount,
                duration_months,
                source_of_income,
                status: 'pending',
                total_amount: totalAmount,
                monthly_installment: monthlyInstallment,
                interest_rate: interestRate * 100, // Store as percentage
            }])
            .select("*,user:users(id,name,gender,country)");  // Select to return inserted data

        if (loanError) {
            return res.status(400).json({ error: 'Something went wrong while applying for the loan.' });
        }

        // **Generate monthly payment invoices**
        const paymentInvoices = [];
        for (let i = 1; i <= duration_months; i++) {
            paymentInvoices.push({
                loan: loan[0].id,
                user,
                amount: monthlyInstallment,
                due_date: new Date(new Date().setMonth(new Date().getMonth() + i)), // Set due date for each month
                status: 'unpaid',
            });
        }

        // **Insert payment invoices**
        const { error: paymentError } = await supabase
            .from('payments')
            .insert(paymentInvoices);

        if (paymentError) {
            return res.status(400).json({ error: 'Something went wrong while generating payment invoices.' });
        }

        res.status(200).json({ message: 'Loan applied successfully', loan, paymentInvoices });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
};


const getUserLoans = async (req, res) => {
    const { user_id } = req.params; // Get user_id from request parameters

    if (!user_id) {
        return res.status(400).json({ error: 'User ID is required' });
    }

    try {
        // Fetch loan applications for the user
        const { data: loans, error } = await supabase
            .from('loan_applications')
            .select('*, user:users(id,name,gender,country)') // Include user details
            .eq('user', user_id);

        if (error) {
            return res.status(400).json({ error: 'Something went wrong.' });
        }

        if (loans.length === 0) {
            return res.status(404).json({ error: 'No loans found for this user.' });
        }

        // Extract user data from the first loan record
        const { user, ...loanDetails } = loans[0];

        // Remove duplicate user data from loans
        const loanArray = loans.map(({ user, ...loan }) => loan);

        res.status(200).json({ user, loans: loanArray });
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
    }
};


const uploadFile = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        const { originalname, mimetype, buffer } = req.file;
        const fileName = `${Date.now()}-${originalname}`; // Unique file name

        // Upload file to Supabase Storage
        const { data, error } = await supabase.storage
            .from('uploads') // Replace with your bucket name
            .upload(fileName, buffer, {
                contentType: mimetype, // Set the correct MIME type
                upsert: false // Prevent overwriting existing files
            });

        if (error) {
            return res.status(400).json({ error: error.message });
        }

        // Get public URL correctly
        const { data: publicUrlData } = supabase.storage
            .from('uploads')
            .getPublicUrl(fileName);

        const publicURL = publicUrlData.publicUrl;

        console.log("Public File URL:", publicURL, publicUrlData);
        res.status(200).json({ message: 'File uploaded successfully', fileUrl: publicURL });
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
    }
};


// const loanPayment = async (req, res) => {
//     const { user_id, loan_id, amount, receipt } = req.body; // Get data from request body
//     console.log("user_id, loan_id, amount, receipt", user_id, loan_id, amount, receipt)
//     if (!user_id || !loan_id || !amount || !receipt) {
//         return res.status(400).json({ error: 'All fields (user_id, loan_id, amount, receipt) are required' });
//     }

//     try {
//         // Fetch the loan to get remaining amount
//         const { data: loan, error: loanError } = await supabase
//             .from('loan_applications')
//             .select('id, amount')
//             .eq('id', loan_id)
//             .single();

//         if (loanError || !loan) {
//             return res.status(404).json({ error: 'Loan not found' });
//         }

//         // Fetch previous payments to calculate remaining amount
//         const { data: previousPayments, error: paymentsError } = await supabase
//             .from('payments')
//             .select('amount')
//             .eq('loan', loan_id);

//         if (paymentsError) {
//             return res.status(400).json({ error: 'Error fetching previous payments' });
//         }

//         // Calculate remaining amount
//         console.log(previousPayments)
//         const totalPaid = previousPayments.reduce((sum, p) => sum + Number(p.amount), 0);
//         console.log(totalPaid)
//         const remainingAmount = Number(loan.amount) - Number(totalPaid) - Number(amount);
//         console.log("remainingAmountremainingAmount", remainingAmount)
//         if (remainingAmount === 0) {
//             await supabase
//                 .from('loan_applications')
//                 .update({ status: 'completed' })  // یہاں مطلوبہ status سیٹ کریں
//                 .eq('id', loan_id)  // loan_id کی بنیاد پر مخصوص درخواست کو اپڈیٹ کریں
//                 .select();

//         }

//         if (remainingAmount < 0) {
//             return res.status(400).json({ error: 'Payment exceeds remaining loan amount' });
//         }

//         // Insert the new payment record
//         const { data: payment, error: paymentError } = await supabase
//             .from('payments')
//             .insert([
//                 { user: user_id, loan: loan_id, amount, receipt, remaning_amount: remainingAmount }
//             ])
//             .select()
//             .single();

//         if (paymentError) {
//             return res.status(400).json({ error: 'Error processing payment' });
//         }

//         res.status(201).json({ message: 'Payment recorded successfully', payment });
//     } catch (err) {
//         res.status(500).json({ error: 'Internal server error' });
//     }
// };

const loanPayment = async (req, res) => {
    const { receipt, status } = req.body; // Get data from request body
    const { id,loan } = req.params; // Get loan ID from request params

    if (!id || !receipt) {
        return res.status(400).json({ error: 'Loan ID and receipt are required' });
    }

    try {
        // Fetch the specific unpaid invoice for the loan
        const { data: invoice, error: invoiceError } = await supabase
            .from('payments')
            .select('*')
            .eq('id', id)
            .eq('status', 'unpaid')
            .limit(1)
            .single();

        if (invoiceError || !invoice) {
            return res.status(404).json({ error: 'No unpaid invoice found for this loan' });
        }


        // Format the payment date
        const paidAt = new Date().toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
        });


        // Update the invoice status to paid and add the receipt
        const { error: updateError } = await supabase
            .from('payments')
            .update({
                status: 'paid',
                receipt,
                paid_at: paidAt, // Record payment timestamp
            })
            .eq('id', invoice.id);

        if (updateError) {
            return res.status(400).json({ error: 'Error updating invoice status' });
        }

        // Check if all invoices for the loan are paid
        const { data: remainingInvoices, error: remainingError } = await supabase
            .from('payments')
            .select('id')
            .eq('loan', loan)
            .eq('status', 'unpaid');

        if (remainingError) {
            return res.status(400).json({ error: 'Error checking remaining invoices' });
        }

        // If no unpaid invoices remain, update the loan status to completed
        if (!remainingInvoices || remainingInvoices.length === 0) {
            await supabase
                .from('loan_applications')
                .update({ status: 'completed' })
                .eq('id', id);
        }

        res.status(200).json({ message: 'Payment recorded successfully', invoiceId: invoice.id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
};


const getLoanUserPayments = async (req, res) => {
    const { user_id, loan_id } = req.params; // Get user_id & loan_id from URL params

    if (!user_id || !loan_id) {
        return res.status(400).json({ error: 'User ID and Loan ID are required' });
    }

    try {
        // Fetch payments for the user on a specific loan
        const { data: payments, error } = await supabase
            .from('payments')
            .select('*, loan:loan_applications(*)')
            .eq('user', user_id)
            .eq('loan', loan_id);

        if (error) {
            return res.status(400).json({ error: 'Error fetching payments' });
        }

        if (payments.length === 0) {
            return res.status(404).json({ error: 'No payments found for this loan and user.' });
        }

        // Extract loan details (same for all payments)
        const { loan, ...paymentDetails } = payments[0];

        res.status(200).json({ loan, payments });
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
    }
};


const getUserPayments = async (req, res) => {
    const { user_id } = req.params; // Get user ID from URL params

    if (!user_id) {
        return res.status(400).json({ error: 'User ID is required' });
    }

    try {
        // Fetch payments for the user with loan details
        const { data: payments, error } = await supabase
            .from('payments')
            .select('*, loan:loan_applications(*)')
            .eq('user', user_id);

        if (error) {
            return res.status(400).json({ error: 'Error fetching payments' });
        }

        if (payments.length === 0) {
            return res.status(404).json({ error: 'No payments found for this user' });
        }

        res.status(200).json({ user_id, payments });
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getInvoice = async (req, res) => {
    const { id } = req.params; // Get user ID from URL params

    if (!id) {
        return res.status(400).json({ error: 'ID is required' });
    }

    try {
        // Fetch payments for the user with loan details
        const { data: payments, error } = await supabase
            .from('payments')
            .select('*')
            .eq('id', id)
            .limit(1)
            .single();

        if (error) {
            return res.status(400).json({ error: 'Error fetching payments' });
        }

        if (payments.length === 0) {
            return res.status(404).json({ error: 'No invoice found.' });
        }

        res.status(200).json({ payments });
    } catch (err) {
        res.status(500).json({ error: 'Internal server error' });
    }
};






module.exports = {
    getInvoice,
    register,
    login,
    loanApp,
    getUserLoans,
    uploadFile,
    loanPayment,
    getLoanUserPayments,
    getUserPayments,
};
