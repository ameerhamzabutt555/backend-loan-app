const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const multer = require('multer');
// Configure multer to store files in memory
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Register route
router.post('/register', authController.register);

// Login route
router.post('/login', authController.login);

// Loan Application route
router.post('/loan-application', authController.loanApp);

// Route (assuming you're using Express)
router.get('/user-loans/:user_id', authController.getUserLoans);

router.post('/file', upload.single('file'), authController.uploadFile);

// payment
router.post('/payment', authController.loanPayment);
// payment
router.patch('/invoice-pay/:id/:loan', authController.loanPayment);

router.get('/user-loan-payment/:user_id/:loan_id', authController.getLoanUserPayments);

router.get('/user-all-payment/:user_id', authController.getUserPayments);
router.get('/invoice/:id', authController.getInvoice);





module.exports = router;