const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const dotenv = require('dotenv');
const supabase = require('./services/supabaseService'); // Import Supabase client
const authRoutes = require('./routes/authRoutes');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(cors());

// Routes
app.use('/auth', authRoutes);

// Function to check Supabase connection
const checkSupabaseConnection = async () => {
  try {
    // Test the connection by querying a table (e.g., 'customers')
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .limit(1);

    if (error) {
      throw error;
    }

    console.log('Database connected successfully!');
  } catch (error) {
    console.error('Error connecting to the database:', error.message);
    process.exit(1); // Exit the process if the database connection fails
  }
};

// Start the server and check Supabase connection
const startServer = async () => {
  try {
    // Check Supabase connection
    await checkSupabaseConnection();

    // Start the server
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start the server:', error.message);
    process.exit(1); // Exit the process if the server fails to start
  }
};

// Start the server
startServer();